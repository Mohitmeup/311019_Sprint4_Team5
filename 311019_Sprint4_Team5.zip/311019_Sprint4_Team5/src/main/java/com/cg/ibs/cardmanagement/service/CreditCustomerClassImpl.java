package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardStatus;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.dao.CaseIdDao;
import com.cg.ibs.cardmanagement.dao.CaseIdDaoImpl;
import com.cg.ibs.cardmanagement.dao.CreditCardDao;
import com.cg.ibs.cardmanagement.dao.CreditCardDaoImpl;
import com.cg.ibs.cardmanagement.dao.CreditCardTransactionDao;
import com.cg.ibs.cardmanagement.dao.CreditCardTransactionDaoImpl;
import com.cg.ibs.cardmanagement.dao.CustomerDao;
import com.cg.ibs.cardmanagement.dao.CustomerDaoImpl;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CreditCustomerClassImpl extends CustomerServiceImpl implements CreditCustomer {
	private static Logger logger = Logger.getLogger(CreditCustomerClassImpl.class);

	CaseIdDao caseIdDao = new CaseIdDaoImpl();

	CreditCardTransactionDao creditCardTransactionDao = new CreditCardTransactionDaoImpl();

	CreditCardDao creditCardDao = new CreditCardDaoImpl();
	CustomerDao customerDao = new CustomerDaoImpl();

	@Override
	public String requestCreditCardUpgrade(BigInteger creditCardNumber, int myChoice) throws IBSException {
		logger.info("entered into requestCreditCardUpgrade method of CreditCustomerClassImpl class");
		String status = creditCardDao.getCreditCardStatus(creditCardNumber);

		if (status.equals("Blocked")) {
			throw new IBSException(ErrorMessages.CARD_BLOCK_MESSAGE);
		} else {

			caseIdGenOne = "RCCU";
			timestamp = LocalDateTime.now();

			caseIdTotal = addToServiceRequestTable(caseIdGenOne);
			customerReferenceID = (caseIdTotal + random.nextInt(100));
			caseIdObj.setCaseIdTotal(caseIdTotal);
			caseIdObj.setCaseTimeStamp(timestamp);
			caseIdObj.setStatusOfServiceRequest("Pending");
			caseIdObj.setCardNumber(creditCardNumber);
			caseIdObj.setUCI(creditCardDao.getCreditUci(creditCardNumber));
			caseIdObj.setCustomerReferenceId(customerReferenceID);
			if (myChoice == 1) {
				caseIdObj.setDefineServiceRequest("Gold");
				caseIdDao.actionServiceRequest(caseIdObj);
				return (customerReferenceID);
			} else if (myChoice == 2) {
				caseIdObj.setDefineServiceRequest("Platinum");
				caseIdDao.actionServiceRequest(caseIdObj);
				return (customerReferenceID);
			} else {
				return ("Choose a valid option");
			}
		}

	}

	public void resetCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException {
		logger.info("entered into resetCreditPin method of CreditCustomerClassImpl class");
		try {
			creditCardDao.setNewCreditPin(creditCardNumber, newPin);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}
	}

	@Override
	public String applyNewCreditCard(String newCardType, BigInteger uci) throws IBSException {
		logger.info("entered into applyNewCreditCard method of CreditCustomerClassImpl class");
		caseIdGenOne = "ANCC";
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		timestamp = LocalDateTime.now();
		caseIdObj.setCaseTimeStamp(timestamp);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setDefineServiceRequest(newCardType);
		caseIdObj.setUCI(uci);
		try {
			caseIdDao.actionServiceRequest(caseIdObj);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}

		return customerReferenceID;
	}

//	@Override
//	public String requestCreditCardLost(BigInteger creditCardNumber) throws IBSException {
//		logger.info("entered into requestCreditCardLost method of CreditCustomerClassImpl class");
//		caseIdGenOne = "RCCL";
//		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
//		customerReferenceID = (caseIdTotal + random.nextInt(100));
//		timestamp = LocalDateTime.now();
//
//		caseIdObj.setCaseIdTotal(caseIdTotal);
//		caseIdObj.setCaseTimeStamp(timestamp);
//		caseIdObj.setStatusOfServiceRequest("Pending");
//		caseIdObj.setUCI(creditCardDao.getCreditUci(creditCardNumber));
//		caseIdObj.setCardNumber(creditCardNumber);
//		caseIdObj.setDefineServiceRequest("Blocked");
//		
//		caseIdObj.setCustomerReferenceId(customerReferenceID);
//		try {
//			caseIdDao.actionServiceRequest(caseIdObj);
//		} catch (IBSException e) {
//			throw new IBSException(ErrorMessages.l);
//		}
//
//		return (customerReferenceID);
//	}
	
	@Override

	public void requestCreditCardLost(BigInteger creditCardNumber) throws IBSException {

		try {

			creditCardDao.blockCreditCard(creditCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}
	@Override
	public String raiseCreditMismatchTicket(BigInteger transactionId) throws IBSException {
		logger.info("entered into raiseCreditMismatchTicket method of CreditCustomerClassImpl class");
		caseIdGenOne = "RCMT";

		timestamp = LocalDateTime.now();
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setUCI(creditCardTransactionDao.getCMUci(transactionId));
		caseIdObj.setDefineServiceRequest("Transaction ID:" + transactionId);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdObj.setCardNumber(creditCardTransactionDao.getCreditCardNumber(transactionId));
		caseIdDao.actionServiceRequest(caseIdObj);
		return (customerReferenceID);

	}

	@Override
	public List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException {
		List<CreditCardTransaction> creditCardBeanTrns = creditCardTransactionDao.getCreditTrans(days,
				creditCardNumber);
		if (creditCardBeanTrns.isEmpty())
			throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
		return creditCardBeanTrns;
	}

	@Override
	public List<CreditCardBean> viewAllCreditCards() throws IBSException {
		try {
			return creditCardDao.viewAllCreditCards();
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}

	}

}
