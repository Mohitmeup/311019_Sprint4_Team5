package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CaseIdDao {

	String getNewType(String queryId) throws IBSException;

	void setQueryStatus(String queryId, String newStatus) throws IBSException;

	boolean verifyQueryId(String queryId) throws IBSException;

	List<CaseIdBean> viewAllQueries() throws IBSException;

	

	BigInteger getNewUCI(String queryId) throws IBSException;

	void actionServiceRequest(CaseIdBean caseIdObj) throws IBSException;

	String getCustomerReferenceStatus(CaseIdBean caseIdObj, String customerReferenceId) throws IBSException;

	CaseIdBean getCaseObj(String queryId);

	
}
